import os

files = "'No path'"

while True:
        Ecmd = input('Explorer>')
        
        if Ecmd == 'dir':
                files = os.listdir('Files/')
                try:
                        i = 0
                        for i in files:
                            print(i,'\r\n',end='')
                except Exception as e:
                        print('ERROR',e)

        elif Ecmd[0:3] == 'del':
                delfile = Ecmd[4:1000]
                delchoose = input('确定要删除吗？[Y/N]')
                if delchoose == 'Y' or delchoose == 'y':
                        try:
                                os.system(f'del Files\{delfile}')
                        except FileNotFoundError:
                                print('无此文件')
                elif delchoose == 'N' or delchoose == 'n':
                        pass
                else:
                        print('操作不正确，请重试！')

        elif Ecmd == 'quit' or Ecmd == 'exit' or Ecmd == 'close':
                os.system('cls')
                break

        else:
                print('语法不正确或无此命令')
