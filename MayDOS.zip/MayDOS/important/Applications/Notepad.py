import os
from colorama import Fore, init

init(autoreset=True)

def cls():
    os.system('cls')

def save_note():
    note_name = input('请输入要创建的文件的名称（例：New.txt）>')
    note_open = open(f'Files/{note_name}',mode='w')
    while True:
        note = input('~')
        if note == 'quit':
            break
        else:
            note_open.write(f'{note}\n')

    note_open.close()

def read_note():
    while True:
        try:
            files = os.listdir('Files/')
            print(files)
            print(Fore.GREEN + '请用数字选择文件（起点为0）')
            
            filechoose = input('>')

            if filechoose == 'quit' or filechoose == 'exit' or filechoose == 'close':
                break
            
            filechoose_int = int(filechoose)
            filename = files[filechoose_int]
            
            try:    
                file_open = open(f'Files/{filename}',mode='r',newline='\r\n')
                read = file_open.readlines()
                i = 0
                for i in read:
                    print(Fore.CYAN + '~',i,end='')
                file_open.close()
                print()
                print()
                
            except FileNotFoundError:
                print(Fore.RED + '未找到文件')

        except Exception as e:
            print(Fore.RED + 'ERROR:',e)
        
def main():
    print(Fore.CYAN +"记事本")
    while True:
        print(Fore.GREEN +"\n菜单：")
        print(Fore.GREEN +"1. 保存内容")
        print(Fore.GREEN +"2. 查看上次保存的内容")
        print(Fore.GREEN +"3. 退出")

        choice = input("请输入选项数字（1/2/3）：")

        if choice == "1":
            cls()
            save_note()
        elif choice == "2":
            cls()
            read_note()
        elif choice == "3":
            print(Fore.GREEN +"退出记事本")
            break
        else:
            cls()
            print(Fore.YELLOW + "无效的选项，请重新输入")

if __name__ == "__main__":
    main()
