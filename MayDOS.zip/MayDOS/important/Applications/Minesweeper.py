import random
import time
from time import sleep
from colorama import Fore, init

print(Fore.GREEN + '欢迎使用由Annie_Cathy制作的扫雷游戏.')

def create_board(rows, cols, num_mines):
    board = [[' ' for _ in range(cols)] for _ in range(rows)]
    mine_locations = random.sample(range(rows*cols), num_mines)
    for loc in mine_locations:
        row = loc // cols
        col = loc % cols
        board[row][col] = 'X'
    return board

def get_adjacent_mines(board, row, col):
    count = 0
    rows = len(board)
    cols = len(board[0])

    for i in range(max(0, row - 1), min(rows, row + 2)):
        for j in range(max(0, col - 1), min(cols, col + 2)):
            if board[i][j] == 'X':
                count += 1

    return count

def print_board(board):
    rows = len(board)
    cols = len(board[0])

    print('   ', end='')
    for i in range(cols):
        print(f'{i} ', end='')
    print()

    print('  +' + '--'*cols)

    for i in range(rows):
        print(f'{i} |', end='')
        for j in range(cols):
            print(f'{board[i][j]} ', end='')
        print()

    print('  +' + '--'*cols)

def play_game():
    rows = int(input(Fore.RED + "请输入行数："))
    cols = int(input(Fore.RED + "请输入列数："))
    num_mines = int(input(Fore.RED + "请输入地雷数量："))

    board = create_board(rows, cols, num_mines)
    visible = [[' ' for _ in range(cols)] for _ in range(rows)]
    game_over = False

    while not game_over:
        print_board(visible)
        row = int(input(Fore.RED + "请输入行号："))
        col = int(input(Fore.RED + "请输入列号："))

        if board[row][col] == 'X':
            sleep(1.5)
            print(Fore.RED + '游戏结束，您触雷了！')
            
            game_over = True
        else:
            count = get_adjacent_mines(board, row, col)
            visible[row][col] = str(count)

    print_board(board)

if __name__ == "__main__":
    play_game()
